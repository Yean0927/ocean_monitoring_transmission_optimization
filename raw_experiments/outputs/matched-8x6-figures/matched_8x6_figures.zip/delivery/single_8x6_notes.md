# Delivery-ratio figure, 8 × 6 inches

The figure uses the 24 mean and ± values in `delivery_ratio_mean_sd_input.csv`.
Each category contains all eight configurations, ordered from highest to lowest
mean. Bars preserve the established palette and white hatch patterns; axis title
and tick typography, compact in-plot single-column legend, and 8 × 6 inch canvas
follow the previous version. The legend labels use minus signs for removal
configurations and plus signs for additions.
The cache configurations are displayed as “− Buffer” and “+ Buffer”; the
source-data configuration identifiers remain unchanged.
Legend display labels capitalize the initial letters of Protocol,
Compression, and Buffer in both removal and addition configurations.

Error bars and their caps are omitted at the user's explicit request. All 24
mean values are plotted; the supplied ± values remain in the unmodified input
and exported source-data CSV. Their statistical meaning was not specified.
Bar outlines are also omitted. The in-plot legend remains lowered to the right
of the bars. The y-axis extends to 104% to provide a compact margin above the
largest mean (99.93%). No bar-top value labels are used. Bar heights use the
exact input means; no value is rounded to 100%.

PNG is 2400 × 1800 pixels at 300 dpi; TIFF is 4800 × 3600 pixels at 600 dpi.
PDF and SVG retain vector bars, patterns, axes, and text. Reproduce with
`python3 plot_single_delivery_ratio_8x6.py`.

Matched-layout revision: both the delivery-ratio and buffer-capacity figures now have an identical 8 × 6 inch canvas and identical plot bounds (left=0.15, right=0.82, bottom=0.16, top=0.94). Each plot rectangle is exactly 5.36 × 4.68 inches and has the same vertical position. The final rendered geometry comparison finds zero edge differences. Both fresh PDF text and collision audits pass.
The categorical x-axis upper limit is now 3.30 to reserve space for the original in-plot legend within the narrower plot rectangle. A rendered-rectangle guard verifies the legend does not intersect any of the 24 bars. Bar heights, ordering, patterns and source means are unchanged.
